//
//  MovieService.swift
//  Flix
//
//  Created by Griffin Davidson on 2/20/22.
//

import Foundation

class MovieService
{
    static let shared = MovieService()
    
    func fetchMovies(_ completion: @escaping(([Movie]) -> Void))
    {
        let apiKey = "7449dcb61a9a45f28659182b2de515fd"
        let accessToken = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI3NDQ5ZGNiNjFhOWE0NWYyODY1OTE4MmIyZGU1MTVmZCIsInN1YiI6IjYyMTQ1NDlhMzgzZGYyMDA0MjQ1NzE1MCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ._3VNs1H_6gj_LRjVWU803bmJ8nDNuzLvu8urDIx1cYU"
        let url = URL(string: "https://api.themoviedb.org/3/movie/now_playing?api_key=\(apiKey)")!
        
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 10)
        request.httpMethod = "GET"
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.addValue("application/iOS;charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        let session = URLSession(configuration: .default,
                                 delegate: nil,
                                 delegateQueue: .main)
        let task = session.dataTask(with: request)
        { data, response, error in
            guard error == nil else
            {
                print("Error Detected!")
                print("\(error?.localizedDescription ?? "Unable to parse error")")
                return
            }
            
            guard let data = data else
            {
                print("No data detected!")
                return
            }
            
            guard let response = response else
            {
                print("Missing Response!")
                return
            }
            print("Testing Console...")
            print("Response: \(response)")
            
            let dataDictionary = try! JSONSerialization.jsonObject(with: data, options: []) as! [String: Any]
            let movieRawData = dataDictionary["results"] as! [[String: Any]]
            var movies = [Movie]()
            for rawData in movieRawData
            {
                let movie = Movie(title: rawData["original_title"] as! String,
                                  description: rawData["overview"] as! String,
                                  posterURL: rawData["poster_path"] as! String,
                                  year: rawData["release_date"] as! String)
                movies.append(movie)
                
                
            }
    
            completion(movies)
        }
        task.resume()
    }
                                        
    
}
