//
//  ViewController.swift
//  Flix
//
//  Created by Griffin Davidson on 2/19/22.
//
// --MARK ATTRIBUTIONS
//
//Camera icons created by Freepik - Flaticon
//https://www.flaticon.com/free-icons/camera

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var movieTableView: UITableView!
    private var movies = [Movie]()
    {
        didSet
        {
            movieTableView.reloadData()
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        movieTableView.dataSource = self
        movieTableView.delegate = self
        
        MovieService.shared.fetchMovies(
        { movies in
            self.movies = movies
        })
        
        navigationItem.largeTitleDisplayMode = .never
        navigationItem.title = "Flix"
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return movies.count //Number of rows of cells
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 225
    }

    
    // What type of cell do we want to show for each row?
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MovieTableViewCell") as? MovieTableViewCell
        else
        {
            return UITableViewCell()
        }
        cell.configure(with: movies[indexPath.row])
        
        return cell
    }
    
}

