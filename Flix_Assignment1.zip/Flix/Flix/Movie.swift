//
//  Movie.swift
//  Flix
//
//  Created by Griffin Davidson on 2/20/22.
//

import Foundation

struct Movie {
    let title: String
    let description: String
    let posterURL: String
    let year: String
}
