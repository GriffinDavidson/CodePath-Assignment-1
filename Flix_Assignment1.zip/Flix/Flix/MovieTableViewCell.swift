//
//  MovieTableViewCell.swift
//  Flix
//
//  Created by Griffin Davidson on 2/20/22.
//

import UIKit
import AlamofireImage

class MovieTableViewCell: UITableViewCell
{
    
    let baseURL = "https://image.tmdb.org/t/p/w185"
    
    @IBOutlet weak var movieTitleLabel: UILabel!
    @IBOutlet weak var movieDescriptionLabel: UILabel!
    @IBOutlet weak var movieReleaseYear: UILabel!
    @IBOutlet weak var moviePosterImage: UIImageView!
    
    func configure(with movie: Movie)
    {
        movieTitleLabel.text = "\(movie.title)"
        movieDescriptionLabel.text = "\(movie.description)"
        movieReleaseYear.text = "\(movie.year)"
        moviePosterImage.af.setImage(withURL: URL(string: baseURL + movie.posterURL)!)
        print("\nPOSTER URL: \(baseURL + movie.posterURL)\n")
    }
}
